# src/shebangMarkdownIDE/cli.py

from .app import run_app

def main():
    run_app()
    